import areaOfCircle from "./modules/areaOfCircle.js";

const getFromDataSomeWhare = 300;
console.log(areaOfCircle(getFromDataSomeWhare));